import { Test, TestingModule } from '@nestjs/testing';
import { VirtualDeviceController } from './virtual-device.controller';
import { VirtualDeviceService } from './virtual-device.service';

describe('VirtualDeviceController', () => {
  let controller: VirtualDeviceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [VirtualDeviceController],
      providers: [VirtualDeviceService],
    }).compile();

    controller = module.get<VirtualDeviceController>(VirtualDeviceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
