import { PartialType } from '@nestjs/mapped-types';
import { VirtualDevice } from '../entities/virtual-device.entity';

export class CreateVirtualDeviceDto extends PartialType(VirtualDevice) {}
