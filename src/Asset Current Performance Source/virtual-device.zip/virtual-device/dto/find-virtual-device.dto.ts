import { FindOptionsWhere } from 'typeorm';
import { VirtualDevice } from '../entities/virtual-device.entity';

export interface FindVirtualDeviceDto extends FindOptionsWhere<VirtualDevice> {}
