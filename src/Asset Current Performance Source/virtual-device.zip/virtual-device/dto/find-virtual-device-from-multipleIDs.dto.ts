export interface FindVirtualDeviceFromMultipleIDs {
  csvOrgIDs?: string;
  csvAssetTypeIDs?: string;
  csvAssetIDs?: string;
  csvVirtualDeviceIDs?: string;
  csvDeviceIDs?: string;
}
