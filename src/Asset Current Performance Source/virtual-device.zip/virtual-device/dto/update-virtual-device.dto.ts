import { PartialType } from '@nestjs/swagger';
import { CreateVirtualDeviceDto } from './create-virtual-device.dto';

export class UpdateVirtualDeviceDto extends PartialType(CreateVirtualDeviceDto) {}
