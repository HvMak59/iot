import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { winstonServerLogger } from 'app_config/serverWinston.config';
import { FindOptionsOrder, In, IsNull, Repository } from 'typeorm';
import { deleteRec, restore, softDelete } from 'utils/cmnFn.repository';
import { CreateVirtualDeviceDto } from './dto/create-virtual-device.dto';
import { FindVirtualDeviceDto } from './dto/find-virtual-device.dto';
import { UpdateVirtualDeviceDto } from './dto/update-virtual-device.dto';
import { VirtualDevice } from './entities/virtual-device.entity';

import serviceConfig from '../../app_config/service.config.json';
import _ from 'lodash';
import {
  ATTACH_DEVICE_URL,
  DETACH_DEVICE_URL,
  DUPLICATE_RECORD,
  KEY_SEPARATOR,
  NO_RECORD,
  UPDATE_VIRTUAL_DEVICE_GROUP_FROM_VIRTUAL_DEVICE_URL,
  VIRTUAL_DEVICE_GROUP_URL,
} from 'app_config/constants';
import { HttpService } from '@nestjs/axios';
import { getTokenString, throwErrIfSrvcRespFailure } from 'utils/others';
import { firstValueFrom } from 'rxjs';
import { VirtualDeviceGroup } from 'src/virtual-device-group/entities/virtual-device-group.entity';
import { Relations } from 'utils/enums';
@Injectable()
export class VirtualDeviceService {
  private readonly logger = winstonServerLogger(VirtualDeviceService.name);
  private readonly eagerRelations = serviceConfig.virtualDevice.eagerRelations;
  private readonly relations = serviceConfig.virtualDevice.relations;
  private readonly combinedRelations = _.union(
    this.relations,
    this.eagerRelations,
  );
  private schema;
  private appServer;
  private appPort;
  private baseURL;
  constructor(
    @InjectRepository(VirtualDevice)
    private readonly repo: Repository<VirtualDevice>,
    @InjectRepository(VirtualDeviceGroup)
    private readonly vdgRepo: Repository<VirtualDeviceGroup>,
    private readonly httpService: HttpService,
  ) {
    this.schema = process.env['SCHEMA'];
    this.appServer = process.env['APP_SERVER'];
    this.appPort = process.env['APP_PORT'];
    this.baseURL = `${this.schema}://${this.appServer}:${this.appPort}`;
  }
  async create(createVirtualDeviceDto: CreateVirtualDeviceDto, token: string) {
    const result = await this.findOne({
      assetId: createVirtualDeviceDto.assetId,
      name: createVirtualDeviceDto.name,
    });
    if (result != null) {
      throw new Error(
        `${DUPLICATE_RECORD} : ${createVirtualDeviceDto.assetId} ${createVirtualDeviceDto.name} already exists`,
      );
    } else {
      if (
        createVirtualDeviceDto.virtualDeviceGroups == null ||
        createVirtualDeviceDto.virtualDeviceGroups.length == 0
      ) {
        const createVirtualDeviceObj = this.repo.create(createVirtualDeviceDto);
        return await this.repo.save(createVirtualDeviceObj);
      } else {
        const { virtualDeviceGroups, ...createVirtualDeviceWithoutGroups } =
          createVirtualDeviceDto;
        const createVirtualDeviceObj = this.repo.create(
          createVirtualDeviceWithoutGroups,
        );
        const createdVirtualDevice = await this.repo.save(
          createVirtualDeviceObj,
        );
        const virtualDeviceGroupURL = new URL(
          VIRTUAL_DEVICE_GROUP_URL,
          this.baseURL,
        );
        this.logger.debug(
          `virtualDeviceGroupURL : ${virtualDeviceGroupURL.href}`,
        );
        this.httpService.axiosRef.defaults.headers.common['Authorization'] =
          getTokenString(token);
        const createdVirtualDeviceGroups = [];
        for (const virtualDeviceGroup of virtualDeviceGroups) {
          virtualDeviceGroup.virtualDeviceId = createdVirtualDevice.id;
          this.logger.debug(
            `Virtual device group : ${JSON.stringify(virtualDeviceGroup)}`,
          );
          const virtualDeviceGroupURLResp = await firstValueFrom(
            this.httpService.post(
              virtualDeviceGroupURL.href,
              virtualDeviceGroup,
            ),
          );
          throwErrIfSrvcRespFailure(virtualDeviceGroupURLResp);
          createdVirtualDeviceGroups.push(virtualDeviceGroupURLResp.data);
        }
        createdVirtualDevice.virtualDeviceGroups = createdVirtualDeviceGroups;
        return createdVirtualDevice;
      }
    }
  }

  findAll(
    searchCriteria: FindVirtualDeviceDto,
    relationsRequired = Relations.NONE,
  ) {
    const msgTemplate = `findAll() : Input : ${JSON.stringify(searchCriteria)}`;
    return this.repo.find({
      where: searchCriteria,
      relations: {
        virtualDeviceGroups: true,
        /* children: true,
        parent: true, */
        device: {
          deviceModel: true,
        },
      },
      order: { id: 'ASC' },
    });
    /* let relations = this.getRelations(relationsRequired);
    return findAll<VirtualDevice>(
      this.repo,
      msgTemplate,
      relations,
      searchCriteria,
    ); */
  }

  findOne(
    searchCriteria: FindVirtualDeviceDto,
    relationsRequired: boolean = false,
  ) {
    let relations = relationsRequired
      ? this.combinedRelations
      : this.eagerRelations;
    return this.repo.findOne({ where: searchCriteria, relations: relations });
  }

  findOneById(id: string, relation: Relations = Relations.MIN) {
    let relations = this.getRelations(relation);
    return this.repo.findOne({ where: { id: id }, relations: relations });
  }

  findChildrenFromCSVParentIDs(csvParentVirtualIDs: string) {
    this.logger.debug(`csvParentVirtualIDs : ${csvParentVirtualIDs}`);
    return this.repo.find({
      where: {
        id: In(csvParentVirtualIDs.split(',')),
      },
      relations: {
        children: true,
      },
    });
  }

  findWithChildren(assetId?: string) {
    const fnName = 'findWithChildren()';
    this.logger.debug(fnName + KEY_SEPARATOR + 'Input : assetId : ' + assetId);
    const orderBy: FindOptionsOrder<VirtualDevice> = {
      auditDateTime: {
        createdAt: 'DESC',
      },
    };
    if (assetId) {
      return this.repo.find({
        where: {
          assetId: assetId,
          parent: IsNull(),
        },
        relations: { children: true, virtualDeviceGroups: true },
        order: orderBy,
      });
    } else {
      return this.repo.find({
        relations: { children: true, virtualDeviceGroups: true },
        order: orderBy,
      });
    }
  }

  /* getSearchObject(findVirtualDeviceFromMultipleIDs: FindVirtualDeviceFromMultipleIDs) {
    const searchObject : FindVirtualDeviceDto = {};
    const findAssetDto: FindAssetDto = {};
    if (findVirtualDeviceFromMultipleIDs.csvOrgIDs) {
      findAssetDto.orgId = In(findVirtualDeviceFromMultipleIDs.csvOrgIDs.split(','));
    }
    if (findVirtualDeviceFromMultipleIDs.csvAssetTypeIDs) {
      searchObject['assetTypeId'] = findVirtualDeviceFromMultipleIDs.csvAssetTypeIDs;
    }
    if (findVirtualDeviceFromMultipleIDs.csvAssetIDs) {
      searchObject['assetId'] = findVirtualDeviceFromMultipleIDs.csvAssetIDs;
    }
    if (findVirtualDeviceFromMultipleIDs.csvVirtualDeviceIDs) {
      searchObject['id'] = findVirtualDeviceFromMultipleIDs.csvVirtualDeviceIDs;
    }
    if (findVirtualDeviceFromMultipleIDs.csvDeviceIDs) {
      searchObject['deviceId'] = findVirtualDeviceFromMultipleIDs.csvDeviceIDs;
    }
    return searchObject;
  } */

  async update(
    id: string,
    updateVirtualDeviceDto: UpdateVirtualDeviceDto,
    token: string,
  ) {
    const fnName = 'update()';
    this.logger.debug(
      `${fnName} : Input : Virtual device id : ${id}, updateVirtualDeviceDto : ${JSON.stringify(
        updateVirtualDeviceDto,
      )}`,
    );
    if (updateVirtualDeviceDto.id == null) {
      updateVirtualDeviceDto.id = id;
    } else if (updateVirtualDeviceDto.id !== id) {
      throw new Error(
        `updateVirtualDeviceDto.id : ${id} does not match with id : ${updateVirtualDeviceDto.id}`,
      );
    } else {
      if (
        updateVirtualDeviceDto.virtualDeviceGroups != null /* &&
        updateVirtualDeviceDto.virtualDeviceGroups.length > 0 */
      ) {
        const { virtualDeviceGroups, ...updateVirtualDeviceWithoutGroups } =
          updateVirtualDeviceDto;

        const result = await this.repo.update(
          id,
          updateVirtualDeviceWithoutGroups,
        );
        if (result.affected === 0) {
          throw new Error(`${NO_RECORD} : Virtual Device ${id} does not exist`);
        }
        const updateVirtualDeviceGroupURL = new URL(
          UPDATE_VIRTUAL_DEVICE_GROUP_FROM_VIRTUAL_DEVICE_URL,
          this.baseURL,
        );
        updateVirtualDeviceGroupURL.searchParams.append('virtualDeviceId', id);
        this.logger.debug(
          `updateVirtualDeviceGroupURL : ${updateVirtualDeviceGroupURL.href}`,
        );
        this.httpService.axiosRef.defaults.headers.common['Authorization'] =
          getTokenString(token);
        const virtualDeviceGroupURLResp = await firstValueFrom(
          this.httpService.patch<VirtualDeviceGroup[]>(
            updateVirtualDeviceGroupURL.href,
            virtualDeviceGroups,
          ),
        );
        throwErrIfSrvcRespFailure(virtualDeviceGroupURLResp);
        return updateVirtualDeviceDto;
      } else {
        const result = await this.repo.update(id, updateVirtualDeviceDto);
        if (result.affected === 0) {
          throw new Error(`${NO_RECORD} : Virtual Device ${id} does not exist`);
        } else {
          this.logger.debug(
            `${fnName} : Virtual Device ${id} updated successfully`,
          );
          return updateVirtualDeviceDto;
        }
      }
    }
  }

  attachEntireDevice(virtualDevice: VirtualDevice) {
    const fnName = 'attachEntireDevice()';
    this.logger.debug(`${fnName} : Input : ${JSON.stringify(virtualDevice)}`);
    return this.repo.save(virtualDevice);
  }

  delete(id: string) {
    const msgTemplate = 'Delete ' + id;
    return deleteRec<VirtualDevice>(this.repo, id, msgTemplate);
  }

  softDelete(id: string) {
    const msgTemplate = 'Soft delete ' + id;
    return softDelete<VirtualDevice>(this.repo, id, msgTemplate);
  }

  restore(id: string) {
    const msgTemplate = 'Restore ' + id;
    return restore<VirtualDevice>(this.repo, id, msgTemplate);
  }

  /* async attachDevice(
    id: string,
    deviceId: string,
    clientDeviceId: string,
    token: string,
    updatedBy: string,
  ) {
    const fnName = 'attachDevice()';

    let virtualDevice = await this.findOneById(id, Relations.NONE);
    this.logger.debug(
      `${fnName} : Vitual Device is : ${JSON.stringify(virtualDevice)}`,
    );

    if (virtualDevice == null) {
      this.logger.error(`${fnName} : Virtual Device id :${id} does not exist`);
      throw new Error(
        `${fnName} : ${NO_RECORD} Virtual Device id : ${id} does not exist`,
      );
    } else if (virtualDevice.deviceId != null) {
      throw new Error(
        `${fnName} : Virtual device already has a device ${virtualDevice.deviceId} attached`,
      );
    }

    const findDeviceURL = new URL(DEVICE_FIND_ONE_BY_ID_URL, this.baseURL);
    findDeviceURL.searchParams.append('id', deviceId);
    this.logger.debug(`${fnName} : findDeviceURL : ${findDeviceURL.href}`);
    this.httpService.axiosRef.defaults.headers.common['Authorization'] =
      getTokenString(token);
    const findDeviceURLResp = await firstValueFrom(
      this.httpService.get(findDeviceURL.href),
    );
    throwErrIfSrvcRespFailure(findDeviceURLResp);

    // const device = await this.deviceService.findOneById(deviceId);
    let device = findDeviceURLResp.data;

    if (device == null) {
      this.logger.error(`${fnName} : Device id :${id} does not exist`);
      throw new Error(
        `${fnName} : ${NO_RECORD} Device id : ${deviceId} does not exist`,
      );
    } else if (device.virtualDeviceId != null) {
      throw new Error(
        `${fnName} : Device is already attached to a virtual device`,
      );
    } else {
      device.virtualDeviceId = id;
      device.clientDeviceId = clientDeviceId;
      device.updatedBy = updatedBy;

      // For Device Updation
      const updateDeviceURL = new URL(DEVICE_URL, this.baseURL);
      updateDeviceURL.searchParams.append('id', deviceId);
      this.logger.debug(
        `${fnName} : updateDeviceURL : ${updateDeviceURL.href}`,
      );
      this.httpService.axiosRef.defaults.headers.common['Authorization'] =
        getTokenString(token);
      const updateDeviceURLResp = await firstValueFrom(
        this.httpService.patch(
          updateDeviceURL.href,
          device,
          // newDevice
        ),
      );
      throwErrIfSrvcRespFailure(updateDeviceURLResp);

      this.logger.debug(
        `${fnName} : Updated Device is : ${JSON.stringify(
          updateDeviceURLResp.data,
        )}`,
      );

      // VirtualDevice updation
      virtualDevice.updatedBy = updatedBy;
      virtualDevice.deviceId = deviceId;

      return await this.update(id, virtualDevice, token);
    }
  } */

  async attachDevice(
    token: string,
    updatedBy: string,
    id: string,
    deviceId: string,
    clientDeviceId: string,
    IMEI?: string,
    validateIMEI?: boolean,
    phoneNumber?: string,
  ) {
    const fnName = 'attachDevice()';
    const input = `${fnName} Input : Attach VirtualDeviceId : ${id} with Device where deviceId : ${deviceId}, clientDeviceId : ${clientDeviceId}, IMEI : ${IMEI}, validateIMEI : ${validateIMEI}, phoneNumber : ${phoneNumber}`;

    this.logger.debug(fnName + KEY_SEPARATOR + input);

    let virtualDevice = await this.findOneById(id, Relations.NONE);
    this.logger.debug(
      `${fnName} : Virtual Device is : ${JSON.stringify(virtualDevice)}`,
    );

    if (virtualDevice == null) {
      this.logger.error(
        `${fnName} : ${NO_RECORD} : Virtual Device id : ${id} does not exist`,
      );
      throw new Error(`${NO_RECORD}: Virtual Device id : ${id} does not exist`);
    } else if (virtualDevice.deviceId != null) {
      this.logger.error(
        `${fnName} : Virtual device id : ${id} already has a deviceId : ${virtualDevice.deviceId} attached`,
      );
      throw new Error(
        `Virtual device id : ${id} already has a device attached`,
      );
    }

    const device = {
      virtualDeviceId: id,
      clientDeviceId: clientDeviceId,
      IMEI: IMEI,
      validateIMEI: validateIMEI,
      phoneNumber: phoneNumber,
    };

    // For Device Updation
    const attachDeviceURL = new URL(
      ATTACH_DEVICE_URL, //  ATTACH_DEVICE_URL = `${DEVICE_URL}/attach-virtualDevice`      //logic behind not using DEVICE_URL is in device's update service we've added check updateDTO should not contain deviceModelId and serialNo but here device object will have this both
      this.baseURL,
    );
    attachDeviceURL.searchParams.append('id', deviceId);
    this.logger.debug(`${fnName} : attachDeviceURL : ${attachDeviceURL.href}`);
    this.httpService.axiosRef.defaults.headers.common['Authorization'] =
      getTokenString(token);
    const updateDeviceURLResp = await firstValueFrom(
      this.httpService.patch(attachDeviceURL.href, device),
    );
    throwErrIfSrvcRespFailure(updateDeviceURLResp);

    this.logger.debug(
      `${fnName} : Attached Device is : ${JSON.stringify(
        updateDeviceURLResp.data,
      )}`,
    );

    virtualDevice.deviceId = deviceId;
    virtualDevice.updatedBy = updatedBy;

    return await this.update(id, virtualDevice, token);
  }
  /* async detachDevice(id: string, token: string, updatedBy: string) {
    const fnName = 'detachDevice()';

    const virtualDevice = await this.findOneById(id, Relations.NONE);
    if (virtualDevice == null) {
      this.logger.error(`${fnName} : Virtual Device id :${id} does not exist`);
      throw new Error(`${NO_RECORD} Virtual Device id : ${id} does not exist`);
    } else if (virtualDevice.deviceId == null) {
      this.logger.error(
        `${fnName} : Virtual Device id :${id} is not attached to any device`,
      );
      throw new Error(
        `${fnName} : Virtual Device id : ${id} not attached to any device`,
      );
    } else {
      // const device = await this.deviceService.findOneById(virtualDevice.deviceId);
      const findDeviceURL = new URL(DEVICE_FIND_ONE_BY_ID_URL, this.baseURL);
      findDeviceURL.searchParams.append('id', virtualDevice.deviceId);
      this.logger.debug(`${fnName} : findDeviceURL : ${findDeviceURL.href}`);
      this.httpService.axiosRef.defaults.headers.common['Authorization'] =
        getTokenString(token);
      const findDeviceURLResp = await firstValueFrom(
        this.httpService.get(findDeviceURL.href),
      );
      throwErrIfSrvcRespFailure(findDeviceURLResp);

      let device = findDeviceURLResp.data;
      this.logger.debug(`${fnName} : Device is : ${JSON.stringify(device)}`);

      if (device == null) {
        this.logger.error(
          `${fnName} : Device id :${virtualDevice.deviceId} does not exist`,
        );
        throw new Error(
          `${fnName} : ${NO_RECORD} Device id : ${virtualDevice.deviceId} does not exist`,
        );
      } else if (device.virtualDeviceId != id) {
        this.logger.error(
          `Device id : ${device.id} is not attached to Virtual Device id : ${id}`,
        );
        throw new Error(
          `${fnName} : Device id : ${device.id} is not attached to Virtual Device id : ${id}`,
        );
      } else {
        device.virtualDeviceId = null;
        device.clientDeviceId = null;
        device.updatedBy = updatedBy;

        const updateDeviceURL = new URL(DEVICE_URL, this.baseURL);
        updateDeviceURL.searchParams.append('id', virtualDevice.deviceId);
        this.logger.debug(
          `${fnName} : updateDeviceURL : ${updateDeviceURL.href}`,
        );
        this.httpService.axiosRef.defaults.headers.common['Authorization'] =
          getTokenString(token);
        const updateDeviceURLResp = await firstValueFrom(
          this.httpService.patch(updateDeviceURL.href, device),
        );
        throwErrIfSrvcRespFailure(updateDeviceURLResp);

        this.logger.debug(
          `${fnName} : Updated Device is : ${JSON.stringify(
            updateDeviceURLResp.data,
          )}`,
        );

        // VirtualDevice updation
        virtualDevice.updatedBy = updatedBy;
        virtualDevice.deviceId = null;
        virtualDevice.device = null;

        return await this.update(id, virtualDevice, token);

        // const updatedDevice = await this.deviceService.update(device.id, device);
        // this.logger.debug(`Updated Device is ${JSON.stringify(updatedDevice)}`);

        // virtualDevice.deviceId = null;
        // virtualDevice.updatedBy = id;

        // const mergedVirtualDevice = await this.repo.preload(virtualDevice);
        // this.logger.debug(`Merged VirtualDevice is ${JSON.stringify(mergedVirtualDevice)}`);

        // const savedVirtualDevice = await this.repo.save(mergedVirtualDevice);
        // this.logger.debug(`Saved VirtualDevice is ${JSON.stringify(savedVirtualDevice)}`);

        // return savedVirtualDevice;
      }
    }
  } */

  async detachDevice(token: string, updatedBy: string, id: string) {
    const fnName = 'detachDevice()';
    const input = `${fnName} Input : Detach Device from VirtualDeviceId : ${id}`;

    this.logger.debug(fnName + KEY_SEPARATOR + input);

    const virtualDevice = await this.findOneById(id, Relations.NONE);

    if (virtualDevice == null) {
      this.logger.error(
        `${fnName} : ${NO_RECORD} : Virtual Device id : ${id} does not exist`,
      );
      throw new Error(
        `${NO_RECORD} : Virtual Device id : ${id} does not exist`,
      );
    } else if (virtualDevice.deviceId == null) {
      this.logger.error(
        `${fnName} : Virtual Device id : ${id} is not attached to any device`,
      );
      throw new Error(`Virtual Device id : ${id} not attached to any device`);
    } else {
      const device = {
        virtualDeviceId: null,
        clientDeviceId: null,

        // new added
        // device.IMEI = null;
        // device.validateIMEI = false;
        // device.phoneNumber = null;
      };
      const detachDeviceURL = new URL(
        DETACH_DEVICE_URL, //  DETACH_DEVICE_URL = `${DEVICE_URL}/detach-virtualDevice`
        this.baseURL,
      );
      detachDeviceURL.searchParams.append('id', virtualDevice.deviceId);
      this.logger.debug(
        `${fnName} : detachDeviceURL : ${detachDeviceURL.href}`,
      );
      this.httpService.axiosRef.defaults.headers.common['Authorization'] =
        getTokenString(token);
      const updateDeviceURLResp = await firstValueFrom(
        this.httpService.patch(detachDeviceURL.href, device),
      );
      throwErrIfSrvcRespFailure(updateDeviceURLResp);

      this.logger.debug(
        `${fnName} : Detached Device is : ${JSON.stringify(
          updateDeviceURLResp.data,
        )}`,
      );

      // VirtualDevice updation
      virtualDevice.deviceId = null;
      virtualDevice.updatedBy = updatedBy;

      return await this.update(id, virtualDevice, token);
    }
  }

  getRelations(relation: Relations) {
    let relations;
    switch (relation) {
      case Relations.NONE:
        relations = [];
        break;
      case Relations.MIN:
        relations = this.eagerRelations;
        break;
      case Relations.ALL:
        relations = this.combinedRelations;
        break;
      default:
        this.logger.error(`Invalid relation ${relation}`);
        break;
    }
    return relations;
  }
}
