import { Test, TestingModule } from '@nestjs/testing';
import { VirtualDeviceService } from './virtual-device.service';

describe('VirtualDeviceService', () => {
  let service: VirtualDeviceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [VirtualDeviceService],
    }).compile();

    service = module.get<VirtualDeviceService>(VirtualDeviceService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
