import { Module } from '@nestjs/common';
import { VirtualDeviceService } from './virtual-device.service';
import { VirtualDeviceController } from './virtual-device.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VirtualDevice } from './entities/virtual-device.entity';
import { HttpModule } from '@nestjs/axios';
import { VirtualDeviceGroup } from 'src/virtual-device-group/entities/virtual-device-group.entity';
import { VirtualDeviceMetricsAttributeFormula } from 'src/virtual-device-metrics-attribute-formula/entities/virtual-device-metrics-attribute-formula.entity';

@Module({
  imports: [
    //VirtualDeviceGroupModule,
    TypeOrmModule.forFeature([
      VirtualDevice,
      VirtualDeviceGroup,
      //VirtualDeviceMetricsAttributeFormula,
    ]),
    /*  TypeOrmModule.forFeature([VirtualDeviceGroup]),
    TypeOrmModule.forFeature([VirtualDeviceMetricsAttributeFormula]), */
    HttpModule,
  ],
  controllers: [VirtualDeviceController],
  providers: [VirtualDeviceService],
})
export class VirtualDeviceModule {}
