import { PartialType } from '@nestjs/swagger';
import { CreateDeviceTypeMetricsAttributeDto } from './create-device-type-metrics-attribute.dto';

export class UpdateDeviceTypeMetricsAttributeDto extends PartialType(
  CreateDeviceTypeMetricsAttributeDto,
) {}
